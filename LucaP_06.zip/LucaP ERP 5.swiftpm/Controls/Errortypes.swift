import SwiftUI

enum ErrorType:String{
    case noError = "No error Found"
    case recordNotFound = "Record not found"
    case recordExists = "Record already exists"
    case readOnly = "cannot change record"
}

struct ErrorMessage:View{
    var error:ErrorType
    @Binding var isPresented:Bool
    var isNotIpad:Bool{
        @Environment(\.verticalSizeClass) var vsc
        @Environment(\.horizontalSizeClass) var hsc
        return vsc != .regular && hsc != .regular
    }
    var body: some View{
        VStack{
            Text("Error").font(.title)
            Image(systemName: "exclamationmark.triangle.fill")
                .imageScale(.large)
                .foregroundStyle(.yellow)
            Text(error.rawValue)
                .font(.headline)
            if isNotIpad{
                Button("OK"){
                    isPresented = false
                }
                .font(.headline)
                .padding()
                .background(.regularMaterial)
                .cornerRadius(10)
            }
        }
    }
}

#Preview{
    ErrorMessage(error: .recordExists, isPresented: .constant(true))
}
