import SwiftUI

struct LPCurrencyField:View{
    var label:String
    @Binding var value:Float
    var isActive:Bool = true
    
    var formatter:Formatter{
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        return formatter
    }
    
    var body: some View{
        HStack{
            TextField(label,value:$value,formatter: formatter)
                .lpFieldModifier(label: label, value: formatter.string(for: value) ?? "", isActive: isActive)
                .keyboardType(.decimalPad)
        }
    }
}


#Preview{
    LPCurrencyField(label: "Currency", value: .constant(3.143), isActive: true)
}
